<?php

return [
    'name' => 'Setup',
];
