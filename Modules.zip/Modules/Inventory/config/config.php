<?php

return [
    'name' => 'Inventory',
];
